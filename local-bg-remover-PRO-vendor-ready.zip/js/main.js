(async () => {
  const ort = window.ort;
  const backendEl = document.getElementById('backend');
  const modelStatusEl = document.getElementById('modelStatus');
  const canvas = document.getElementById('canvas');
  const ctx = canvas.getContext('2d');
  const fileInput = document.getElementById('fileInput');
  const dropZone = document.getElementById('dropZone');
  const pickBtn = document.getElementById('pickBtn');
  const downloadPngBtn = document.getElementById('downloadPng');
  const downloadJpgBtn = document.getElementById('downloadJpg');
  const resetBtn = document.getElementById('resetBtn');
  const qualityEl = document.getElementById('quality');
  const featherEl = document.getElementById('feather');
  const denoiseEl = document.getElementById('denoise');
  const trimEl = document.getElementById('trim');
  const bgSelect = document.getElementById('bgSelect');
  const bgColor = document.getElementById('bgColor');

  let session = null;
  let inputImage = null;
  let matte = null;

  function info(msg){ backendEl.textContent = msg; }

  async function initSession(){
    try{
      // If WebGPU is available, ORT will use it; otherwise WASM will be used.
      const providers = (ort.env.webgpu?.adapterInfo) ? ['webgpu','wasm'] : ['wasm'];
      let created = false, lastErr = null;
      for (const p of providers){
        try{
          info(`Backend: ${p.toUpperCase()}…`);
          session = await ort.InferenceSession.create('models/u2netp.onnx', {
            executionProviders: [p],
            graphOptimizationLevel: 'all',
          });
          created = true; info(`Backend: ${p.toUpperCase()}`); break;
        }catch(e){ lastErr = e; console.warn('Provider failed:', p, e); }
      }
      if (!created) throw lastErr || new Error('No backend was created');
      modelStatusEl.textContent = 'Model: Loaded'; modelStatusEl.style.background='#064e3b'; modelStatusEl.style.color='#d1fae5';
    }catch(e){
      info('Backend: Fallback');
      modelStatusEl.textContent = 'Model: FAILED (בדוק את קבצי ORT בתיקיית js/vendor/ort ואת models/u2netp.onnx)';
      modelStatusEl.style.background='#7c2d12'; modelStatusEl.style.color='#ffedd5';
      console.error(e);
    }
  }

  await initSession();

  function showColorPicker(){ bgColor.style.display = (bgSelect.value==='custom') ? 'inline-block' : 'none'; }
  bgSelect.addEventListener('change', showColorPicker); showColorPicker();

  pickBtn.addEventListener('click', ()=> fileInput.click());
  fileInput.addEventListener('change', e => {
    const f = e.target.files?.[0]; if (f) loadImageFile(f);
  });

  ;['dragenter','dragover'].forEach(ev => dropZone.addEventListener(ev, e => {e.preventDefault(); e.stopPropagation(); dropZone.classList.add('drag');}));
  ;['dragleave','drop'].forEach(ev => dropZone.addEventListener(ev, e => {e.preventDefault(); e.stopPropagation(); if(ev==='dragleave') dropZone.classList.remove('drag');}));
  dropZone.addEventListener('drop', e => { dropZone.classList.remove('drag'); const f = e.dataTransfer?.files?.[0]; if (f) loadImageFile(f); });

  resetBtn.addEventListener('click', ()=>{
    inputImage=null; matte=null; canvas.width=800; canvas.height=520; ctx.clearRect(0,0,canvas.width,canvas.height);
    downloadJpgBtn.disabled=true; downloadPngBtn.disabled=true;
  });

  downloadPngBtn.addEventListener('click', ()=> save('png'));
  downloadJpgBtn.addEventListener('click', ()=> save('jpeg'));

  [qualityEl, featherEl, denoiseEl, trimEl, bgSelect, bgColor].forEach(el => el.addEventListener('input', ()=>{ if (inputImage) processAndRender(); }));

  function loadImageFile(file){
    const img = new Image();
    img.onload = ()=>{ inputImage=img; matte=null; processAndRender(); };
    img.onerror = ()=> alert('שגיאה בטעינת התמונה.');
    img.src = URL.createObjectURL(file);
  }

  async function processAndRender(){
    if (!inputImage) return;
    canvas.width = inputImage.naturalWidth; canvas.height = inputImage.naturalHeight;

    if (!matte){
      try{
        if (!session) throw new Error('Session not ready');
        matte = await runU2Net(inputImage, parseInt(qualityEl.value,10));
      }catch(e){
        console.error('AI matte failed, using solid alpha', e);
        matte = new Float32Array(canvas.width*canvas.height); matte.fill(1);
      }
      const passes = parseInt(denoiseEl.value,10)||0;
      if (passes>0) morphOpenClose(matte, canvas.width, canvas.height, passes);
    }

    const feather = parseFloat(featherEl.value||'0');
    if (feather>0) gaussianBlur1D(matte, canvas.width, canvas.height, feather);

    renderComposite(inputImage, matte, getBgColor());

    downloadJpgBtn.disabled=false; downloadPngBtn.disabled=false;
  }

  function getBgColor(){
    const v = bgSelect.value;
    if (v==='transparent') return 'transparent';
    if (v==='white') return '#ffffff';
    if (v==='black') return '#000000';
    if (v==='custom') return bgColor.value;
    return '#ffffff';
  }

  async function runU2Net(img, size){
    const iw=img.naturalWidth, ih=img.naturalHeight;
    const s=Math.min(size/iw, size/ih); const tw=Math.round(iw*s), th=Math.round(ih*s);
    const ox=Math.floor((size-tw)/2), oy=Math.floor((size-th)/2);
    const off = new OffscreenCanvas(size,size); const t=off.getContext('2d');
    t.fillStyle = '#000'; t.fillRect(0,0,size,size);
    t.drawImage(img,0,0,iw,ih, ox,oy,tw,th);
    const im = t.getImageData(0,0,size,size);
    const data = im.data;

    const mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225];
    const chw = new Float32Array(3*size*size);
    for (let y=0;y<size;y++){
      for (let x=0;x<size;x++){
        const i=(y*size + x)*4; const r=data[i]/255, g=data[i+1]/255, b=data[i+2]/255;
        const idx=y*size + x;
        chw[idx]=(r-mean[0])/std[0];
        chw[size*size + idx]=(g-mean[1])/std[1];
        chw[2*size*size + idx]=(b-mean[2])/std[2];
      }
    }

    const inputName = (typeof session.inputNames!=='undefined' && session.inputNames.length) ? session.inputNames[0] : 'input';
    const input = new ort.Tensor('float32', chw, [1,3,size,size]);
    const out = await session.run({[inputName]: input});
    const keys = Object.keys(out);
    const mainKey = keys.find(k=>/^d(0|1)$/i.test(k)) || keys.find(k=>/(prob|output)/i.test(k)) || keys[0];
    const tensor = out[mainKey];
    const oW = tensor.dims.at(-1), oH = tensor.dims.at(-2);
    const raw = tensor.data;

    const res = new Float32Array(iw*ih);
    for (let y=0;y<ih;y++){
      for (let x=0;x<iw;x++){
        const xs = ((x/iw)*tw + ox) * (oW/size);
        const ys = ((y/ih)*th + oy) * (oH/size);
        res[y*iw + x] = bilinear(raw, oW, oH, xs, ys);
      }
    }
    for (let i=0;i<res.length;i++) res[i] = 1/(1+Math.exp(-res[i]));
    const thr = otsu(res);
    for (let i=0;i<res.length;i++) res[i] = res[i] > thr ? 1 : 0;
    return res;
  }

  function bilinear(buf,w,h,x,y){
    const x0=Math.max(0,Math.min(w-1,Math.floor(x)));
    const y0=Math.max(0,Math.min(h-1,Math.floor(y)));
    const x1=Math.min(w-1,x0+1), y1=Math.min(h-1,y0+1);
    const dx=x-x0, dy=y-y0;
    const i00=buf[y0*w + x0], i10=buf[y0*w + x1], i01=buf[y1*w + x0], i11=buf[y1*w + x1];
    return i00*(1-dx)*(1-dy) + i10*dx*(1-dy) + i01*(1-dx)*dy + i11*dx*dy;
  }

  function gaussianBlur1D(a,w,h,sigma){
    if (sigma<=0) return;
    const r=Math.max(1,Math.floor(sigma*2)), k=new Float32Array(2*r+1); const s2=2*sigma*sigma; let sum=0;
    for (let i=-r;i<=r;i++){ const v=Math.exp(-(i*i)/s2); k[i+r]=v; sum+=v; } for (let i=0;i<k.length;i++) k[i]/=sum;
    const tmp=new Float32Array(w*h);
    for (let y=0;y<h;y++){ for (let x=0;x<w;x++){ let acc=0; for (let i=-r;i<=r;i++){ const xx=Math.max(0,Math.min(w-1,x+i)); acc+=a[y*w+xx]*k[i+r]; } tmp[y*w+x]=acc; } }
    for (let x=0;x<w;x++){ for (let y=0;y<h;y++){ let acc=0; for (let i=-r;i<=r;i++){ const yy=Math.max(0,Math.min(h-1,y+i)); acc+=tmp[yy*w+x]*k[i+r]; } a[y*w+x]=acc; } }
  }

  function otsu(buf){
    const hist=new Uint32Array(256); const N=buf.length; for(let i=0;i<N;i++){ const v=Math.max(0,Math.min(255,Math.round(buf[i]*255))); hist[v]++; }
    let sum=0; for (let i=0;i<256;i++) sum+=i*hist[i];
    let sumB=0, wB=0, maxV=-1, thr=127;
    for (let t=0;t<256;t++){ wB+=hist[t]; if(!wB) continue; const wF=N-wB; if(!wF) break; sumB += t*hist[t];
      const mB=sumB/wB, mF=(sum-sumB)/wF, between=wB*wF*(mB-mF)*(mB-mF);
      if (between>maxV){ maxV=between; thr=t; } }
    return thr/255;
  }

  function morphOpenClose(a,w,h,p){
    const tmp=new Float32Array(w*h);
    const K = [[0,-1],[1,0],[0,0],[0,1],[-1,0]];
    const bin=(i)=> a[i]>0.5?1:0;
    const set=(buf,i,v)=> buf[i]=v?1:0;
    for (let iter=0; iter<p; iter++){
      for (let y=0;y<h;y++){ for (let x=0;x<w;x++){ const i=y*w+x; let keep=1; for (const [dx,dy] of K){ const xx=Math.max(0,Math.min(w-1,x+dx)), yy=Math.max(0,Math.min(h-1,y+dy)); if (!bin(yy*w+xx)) {keep=0;break;} } set(tmp,i,keep); } }
      for (let y=0;y<h;y++){ for (let x=0;x<w;x++){ const i=y*w+x; let on=0; for (const [dx,dy] of K){ const xx=Math.max(0,Math.min(w-1,x+dx)), yy=Math.max(0,Math.min(h-1,y+dy)); if (tmp[yy*w+xx]>0.5){on=1;break;} } set(a,i,on); } }
    }
    for (let iter=0; iter<p; iter++){
      for (let y=0;y<h;y++){ for (let x=0;x<w;x++){ const i=y*w+x; let on=0; for (const [dx,dy] of K){ const xx=Math.max(0,Math.min(w-1,x+dx)), yy=Math.max(0,Math.min(h-1,y+dy)); if (a[yy*w+xx]>0.5){on=1;break;} } set(tmp,i,on); } }
      for (let y=0;y<h;y++){ for (let x=0;x<w;x++){ const i=y*w+x; let keep=1; for (const [dx,dy] of K){ const xx=Math.max(0,Math.min(w-1,x+dx)), yy=Math.max(0,Math.min(h-1,y+dy)); if (tmp[yy*w+xx]<=0.5){keep=0;break;} } set(a,i,keep); } }
    }
  }

  function renderComposite(img, alpha, bg){
    const w = img.naturalWidth, h=img.naturalHeight;
    if (bg==='transparent'){ ctx.clearRect(0,0,w,h); } else { ctx.fillStyle = bg; ctx.fillRect(0,0,w,h); }
    const id = ctx.createImageData(w,h); const data=id.data;
    const o = new OffscreenCanvas(w,h); const ot=o.getContext('2d'); ot.drawImage(img,0,0); const src=ot.getImageData(0,0,w,h).data;
    for (let i=0,p=0;i<w*h;i++,p+=4){
      const a = Math.max(0,Math.min(1,alpha[i]));
      data[p]=src[p]; data[p+1]=src[p+1]; data[p+2]=src[p+2]; data[p+3]=Math.round(a*255);
    }
    ctx.putImageData(id,0,0);
    if (trimEl.checked){
      let minX=w, minY=h, maxX=0, maxY=0, found=false;
      for (let y=0;y<h;y++){ for (let x=0;x<w;x++){ const a=alpha[y*w+x]; if (a>0.01){found=true; if(x<minX)minX=x; if(y<minY)minY=y; if(x>maxX)maxX=x; if(y>maxY)maxY=y; } } }
      if (found){
        const cw=maxX-minX+1, ch=maxY-minY+1; const crop=ctx.getImageData(minX,minY,cw,ch);
        canvas.width=cw; canvas.height=ch; ctx.putImageData(crop,0,0);
      }
    }
  }

  function save(fmt){
    const url = canvas.toDataURL('image/'+fmt, fmt==='jpeg'?0.92:1.0);
    const a = document.createElement('a'); a.href=url; a.download='bg-removed.'+(fmt==='jpeg'?'jpg':'png');
    document.body.appendChild(a); a.click(); a.remove();
  }

  resetBtn.click();
})();