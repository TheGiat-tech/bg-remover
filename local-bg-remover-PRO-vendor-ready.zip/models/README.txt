Place u2netp.onnx (~3.6–4.7MB) here.
