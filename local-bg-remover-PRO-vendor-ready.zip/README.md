# Background Remover PRO — Vendor-Ready (Local, No API)

This package is prewired to load **onnxruntime-web** from `js/vendor/ort/`.
Just drop the official files there and it will work offline.

## Put these files into `js/vendor/ort/`
- `ort.min.js` (the main runtime bundle)
- `ort-wasm.wasm`
- `ort-wasm-simd.wasm`
- `ort-wasm-threaded.wasm`
- `ort-wasm-simd-threaded.wasm`

> If you plan to use WebGPU, `ort.min.js` is enough; WASM files are used when WebGPU is unavailable.

## Model
Place `models/u2netp.onnx` (~3.6–4.7MB).

## Run
Open `index.html` directly, or serve locally (`npx http-server .`). All operations are 100% local.
